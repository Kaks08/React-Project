import React, { useEffect } from 'react'
import styled from 'styled-components'
import Totalscore from './Totalscore'
import NumberSelector from './NumberSelector'
import Dice from './Dice'
import  { useState } from 'react'
import Rules from './Rules'

const Gameplay = () => {


    const [selectednumber, SetSelectednumber] = useState();
    const [diceNumber, SetDiceNumber] = useState(1);
    const [score,SetScore] = useState(0);
    const [error, SetError] = useState("");
    const [dicerolled, SetDicerolled] = useState("");
    const [showrule, SetShowrule] = useState(false); 
    const [chancefull, SetChancefull] = useState();
    const [count , SetCount] = useState(0);
    const [finalScore, SetFinalScore] = useState("");
    

    const generateNumber = (min, max) => {
        // console.log("Random Number: " + Math.floor(Math.random() * (max - min) + min));
        return Math.floor(Math.random() * (max - min) + min);
    }
    // const selectednum =()=> {
    //     if(selectednumber != diceNumber)
    //     {
    //         SetDicerolled("")
    //     }else{
    //         SetDicerolled("Dice Rolled!!")
    //     }
    // }

    const rollDice = () => {
        if(count < 10)
        {
            SetCount((prev) => prev+1)
        const rand = generateNumber(1, 7);
        console.log(rand)
        SetDiceNumber((prev) => rand);
        console.log("Dice Number"+diceNumber)
        // if(selectednumber != diceNumber )
        // {
        //     SetDicerolled("")
        // }else
        // {
        //     SetDicerolled("Dice Rolled!!")
        // }
       
        if(!selectednumber)
        {
            SetError("You Have Not Selected Any Number");
            return;
        }else
        {
            SetError("");
        }
        if(selectednumber === rand)
        {
            SetScore((prev) => prev + rand*2);
        }else{
            SetScore((prev) => prev - 2);
        } 

        }else{
            SetFinalScore(score);
            SetChancefull("You have Cross your Roll count, Please Restart Your Game")
            return;
        }
        
    }

    const reset = () =>
    {
        SetScore(0);
        SetDiceNumber(1);
        SetCount(0);
        SetChancefull("")
        SetFinalScore("")

    }
    const toggle =()=> {
        SetShowrule((prev) => !prev);
    }

    return (
        <MainContainer>
            
            <div className='top_section'>
                <Totalscore score={score}/>
                <NumberSelector  selectednumber={selectednumber} SetSelectednumber={SetSelectednumber} error={error}/>
               
                
            </div>
                <Dice  finalScore={finalScore} chancefull={chancefull}  diceNumber={diceNumber} rollDice={rollDice} SetDiceNumber={SetDiceNumber} reset={reset} dicerolled={dicerolled} showrule={showrule} toggle={toggle}/> 
                {showrule && <Rules/>}
                
        </MainContainer>
    )
}

export default Gameplay


const MainContainer =styled.div`
max-height: 100vh;
overflow-y: auto;
/* padding: 70 px; */
.top_section
{
  display  :flex;
  justify-content:space-around;
  align-items: center;
}

`
