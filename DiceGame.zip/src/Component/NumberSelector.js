
import styled from 'styled-components'
const NumberSelector = ({error,selectednumber,SetSelectednumber}) => {


    console.log(selectednumber);

    const arrNumber = [1,2,3,4,5,6];
    return (
        <NumberContainer>
            <p className='error'>{error}</p>
            <div className='flex'>
                {arrNumber.map((value,i) => (
                    <Box onClick={ () => SetSelectednumber(value)}  key={i}  isSelected={value === selectednumber}>
                    {value}
                    </Box>
                ))}

            </div>
            
            <p>Select Number</p>
        </NumberContainer>
       
             
    )
}

export default NumberSelector


const Box = styled.div`
border: 4px solid black;
width: 72px;
height: 72px;
display: flex;
justify-content:center;
align-items: center;
font-weight: 500;
font-size: 24px;
background-color: ${(props)  =>  (props.isSelected?"black":"white")};
color: ${(props) => (!props.isSelected?"black":"white")};
/* &:hover{
    background-color: black;
    color: white;
} */
`

const NumberContainer = styled.div`
display: flex;
flex-direction: column;
align-items: end;
.flex{
    display: flex;
    flex-direction: row;
    gap: 24px;
    justify-content: end;
}

p{
    font-size: 24px;
    font-weight: 700;
}

.error
{
    font-size: 24px;
    font-weight: 700;
    color: red;
}
`
