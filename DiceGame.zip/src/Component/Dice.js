
import styled from 'styled-components'

const Dice = ({diceNumber,rollDice,reset,dicerolled,showrule,toggle,chancefull,finalScore }) => {


    return (
        <DiceContainer>
            <p>{dicerolled}</p>
              <div className='dicecl'>
                    <img src={`/images/dice/dice_${diceNumber}.png`} alt={`dice${diceNumber}`} onClick={rollDice}></img>
                    
              </div>
              <p>Select Dice to Roll</p>
              <div className='chnce'>
                <p>{chancefull}</p>
                <p>{finalScore}</p>
              </div>
              
              <div className='btn'>
                <button className='reset' onClick={reset} >Reset Button</button>
                <button className='shwrule'onClick={toggle} >{showrule? "Hide":"Show"} Rule</button>
              </div>
              
        </DiceContainer>
        
    )
}

export default Dice



const DiceContainer  =styled.div`
max-height: 100vh;
line-height: 0px;
.chnce
{
    color: red;
    text-decoration: underline;
}
.dicecl
{
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: 0.4ms ease-in;
}

p{
    display: flex;
    justify-content:center;
    font-size: 24px;
    font-weight: 500;
}

.btn
{
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 10px;
}

.btn button
{
    font-size: 16px;
    font-weight: 600;
    /* background-color: ${(props)=>(props.isOutline?"white":"black")}; */
    /* color: ${(props)=>(!props.isOutline?"white":"black")}; ; */
    border-color: black;
    padding: 10px 18px;
    min-width:220px;
    border-radius:5px;
    background-color: white;
    cursor: pointer;

    &:hover{
        background-color: black;
        color: white;
        border: transparent;
        /* transition: 0.5ms background ease-in; */
    }
}
`