import StartGame from "./Component/StartGame";
import { useState } from "react";
import Gameplay from "./Component/Gameplay";

function App() {
 const [isgameStarted,SetIsgameStarted] = useState(false);

 const togglecomponent =()=> {
  SetIsgameStarted(true);

  
}
  
const backgroundImage = {
  backgroundImage: 'url("/images/pngwing.com.png")',
  backgroundSize: 'cover',
  backgroundRepeat: 'no-repeat',
  width: '100vw', // Full width of the viewport
  height: '100vh', // Full height of the viewport
  
  

};


return (
    <div className="App" style={backgroundImage}>
      {isgameStarted ? <Gameplay/>:<StartGame  toggle={togglecomponent}/>}
    </div>
  );
}

export default App;
