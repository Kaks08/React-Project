
import styled from 'styled-components';
import './App.css';
import Main from './Component/Main';
import SideNav from './Component/SideNav';

function App() {
  return (
    <div className="App">

      <Cont>
      <SideNav/>
      <Main/>
      </Cont>
      
    </div>
  );
}

export default App;

const Cont =styled.div`
display: flex;
height: 100vh;
width: 100vw;

/* @media(0 < width < 800px){
   flex-direction: column;
   height: 120px;
  }  */
`
