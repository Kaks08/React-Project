import React from 'react'
import styled from 'styled-components'
import { RxDashboard } from "react-icons/rx";
import { AiFillRightCircle } from "react-icons/ai";
import { CiHeart } from "react-icons/ci";
import { TbNotes } from "react-icons/tb";
import { LiaSuitcaseSolid } from "react-icons/lia";
import { MdMessage } from "react-icons/md";
import { IoSettingsOutline } from "react-icons/io5";
import { RxExit } from "react-icons/rx";

const SideNav = () => {
    return (
        <Sidenav>
           <div className='upper'>
           <RxDashboard size={25}/>
            <AiFillRightCircle size={25} />
            <CiHeart size={25}/>
            <TbNotes size={25}/>
            <LiaSuitcaseSolid size={25}/>
            <MdMessage size={25}/>
            <IoSettingsOutline size={25}/>

           </div>
            <div className='lower'>
            <RxExit size={25} />
            </div>
        </Sidenav>
    )
}

export default SideNav


const Sidenav = styled.div`
display: flex;
flex-direction: column;
padding: 30px;
width: 10px;
max-height: 100vh;
align-items: center;
background-color: white;
justify-content: space-between;

.upper
{
    display: flex;
    flex-direction: column;
    gap: 30px;
}

`