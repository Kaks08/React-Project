import React from 'react'
import styled from 'styled-components'
import { IoIosNotifications } from "react-icons/io";
import { IoExitSharp, IoToday } from "react-icons/io5";
import { MdHotel } from "react-icons/md";
import Graph from './Graph';
import MonthView from 'react-calendar';
import Task from './Task';

const Main = () => {

    const btns = [
        {
            btn:<IoExitSharp size={70} color='red'/>,
            heading:"Total Arrived",
            number:"231",
        },
        {
            btn:<MdHotel size={70} color="orange"/>,
            heading:"Total Booked",
            number:"891",
        },
        {
            btn:<IoExitSharp size={70} color='green'/>,
            heading:"Total CheckedIn",
            number:"129",
        }

    ]
    return (
        <Container>
            <TopNav>
                <div className='upwlc'>
                    <h3>
                          Welcome,<b>Ariana!</b>  
                    </h3>
                    <p>Don't forgrt to check your activity</p>
                </div>
                <div className='topside'>
                <IoIosNotifications color='red' size={30} />
                <div className='owner'>    
                    <h4><b>Anjana Abraham</b></h4>
                    <p>owner</p>
                </div>   
                <div>
                  image
                </div>   
                </div>

            </TopNav>
            <MainContent>
                <Content>
                <Cards>
                {
                    btns.map((btn) =>
                    (
                        <Card>
                            <d  iv>{btn.btn}</d>
                            <div>
                                <p>{btn.heading}</p>
                                <h3>{btn.number}</h3>
                            </div>
                        </Card>
                    ))
                }
                </Cards>
                <div className='graph'>
                    <Graph/>
                </div>
                </Content>
                <SideContent>
                        <Calenders>
                            {/* <Calendar/> */}
                            <MonthView/>
                        </Calenders>
                        <Tasks>
                            <Task/>
                        </Tasks>
                </SideContent>
            </MainContent>
            
        </Container>
    )
}

export default Main


const Container = styled.div` 
line-height: 10px;
width: 100vw;
padding:30px;
background-color: whitesmoke;
/* max-height: 100vh; */
/* height: calc(100vh-30px); */


/* @media(0 < width < 800px){
   flex-direction: column;
   height: 200px;
   flex-wrap: wrap;
  } */
`

const TopNav = styled.div`
display: flex;
justify-content: space-between;
.upwlc{
    p{
        color: grey;
    }
}

.topside{
    display: flex;
    line-height: 4px;
    align-items: center;
    justify-content: space-around;
    gap: 30px;

    .owner{
        h4{
           word-spacing: 4px;
           letter-spacing: 1.2px;
           color:tomato;
        }
        p{
            color: grey;
        }
    }
}

`
const MainContent = styled.div`
display: flex;
/* flex-direction:; */
flex-wrap: wrap;
justify-content: space-between;
`

const Content =styled.div`
width: calc(100vw - 500px);
display: flex;
flex-direction: column;
align-items: center;
/* margin: 0 auto; */
/* justify-content: center; */
/* justify-items: center; */
.graph{
    width:calc(100vw - 450px);
    background-color:  white;
    border-radius: 10px;
    height: calc(100vh - 210px);
    /* display: flex;
    justify-content: center;
    align-items: center; */
}
`


const Card =styled.div` background-color:white;
border-radius: 10px;
width: calc(100vw - 900px);
display: flex;
justify-content: center;

`


const Cards = styled.div`
display:flex;
gap: 40px;
width:calc(100vw - 450px);
align-items: center;
justify-content: center;
padding: 10px;
/* background-color: red; */
`


const SideContent = styled.div`
display: flex;
flex-direction: column;
/* justify-content: center; */
align-items: center;
padding: 10px;
gap: 10px;
`

const Calenders =styled.div`
background-color: white;
width: calc(100vw - 950px);
display: flex;
height: 200px;
border-radius: 10px;
justify-content: center;
align-items: center;
`

const Tasks = styled.div`
background-color: white;
width: 300px;
max-height:calc(100vh - 350px);
display: flex;
border-radius: 10px;
margin: 0 auto;
scroll-behavior: auto;
/* justify-content: center; */
/* align-items: center; */
/* padding: 10px; */
`