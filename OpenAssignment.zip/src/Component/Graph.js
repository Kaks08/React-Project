import React from 'react'
import {LineChart,Line
,XAxis,YAxis,Legend,Tooltip,CartesianGrid} from "recharts"

const Graph = () => {


    const data = [
        {
            month:"jan",
            Roomvisited:170,
            RoomBooked:150,

        },
        {
            month:"Feb",
            Roomvisited:120,
            RoomBooked:180,

        },
        {
            month:"Mar",
            Roomvisited:160,
            RoomBooked:150,

        },
        {
            month:"Apr",
            Roomvisited:190,
            RoomBooked:172,

        },
        {
            month:"May",
            Roomvisited:160,
            RoomBooked:185,

        },
        {
            month:"Jun",
            Roomvisited:155,
            RoomBooked:130,

        },
        {
            month:"Jul",
            Roomvisited:197,
            RoomBooked:167,

        },
        {
            month:"Aug",
            Roomvisited:194,
            RoomBooked:161,

        },
        {
            month:"Sep",
            Roomvisited:177,
            RoomBooked:130,

        },
        {
            month:"Oct",
            Roomvisited:145,
            RoomBooked:133,

        },
        {
            month:"Nov",
            Roomvisited:190,
            RoomBooked:187,

        },
        {
            month:"Dec",
            Roomvisited:199,
            RoomBooked:199,

        }

    ]
    return (
        <div>
            <LineChart width={780} height={350} data={data}> 
            <XAxis dataKey="month"/>
            <YAxis style={Line}/>
            <Tooltip/>
            <Legend/>
            <CartesianGrid strokeDasharray={3}/>
            <Line type={'monotone'} dataKey="Roomvisited" stroke='Green'></Line>
            <Line type={'monotone'} dataKey="RoomBooked" stroke='red'></Line>
            </LineChart>
            
        </div>
    )
}

export default Graph
