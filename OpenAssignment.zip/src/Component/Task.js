import React from 'react'
import styled from 'styled-components'

const Task = () => {

    const cust = [
        {
            name:"Aashish",
            room:"Single",
            Amount:"Paid",
        },
        {
            name:"Nkhil",
            room:"Double",
            Amount:"Unpaid",
        },
        {
            name:"kunal",
            room:"Double",
            Amount:"Paid",
        },
        {
            name:"Yash",
            room:"Single",
            Amount:"Paid",
        },
        {
            name:"Rahul",
            room:"Single",
            Amount:"Paid",
        },
        {
            name:"Sakshi",
            room:"Single",
            Amount:"Unpaid",
        },
    ]
    return (
        <Tables className='table'>
            <h4>Booking List</h4>
            <table>
                {/* <tr>
                <th>Name</th>
                <th>Room</th>
                <th>Payment</th>
                </tr> */}
                
                {cust.map((value)=>(
                    <tr>
                        <td><h5>{value.name}</h5></td>
                        <td>{value.room}</td>
                        <td><button>{value.Amount}</button></td>
                    </tr>
                    
                ))}
            </table>
            
        </Tables>
    )
}

export default Task


const Tables = styled.div`
overflow: scroll;
width: 300px;
h4{
    color: brown;
    letter-spacing: 1px;
}
h5{
    color: gray;
}

button{
    background-color: tomato;
    border: none;
    border-radius: 2px;
    color: white;
    font-weight: 100px;
}
table{
    width: 100%;
}
`