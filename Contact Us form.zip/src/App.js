import logo from './logo.svg';
import './App.css';
import Navbar from './Component/Navbar';
import ContactHeader from './Component/ContactHeader';
import ContactDetail from './Component/ContactDetail';

function App() {
  return (
    <div className="App">
      <Navbar/>
      <ContactHeader/>
      <ContactDetail/>
    </div>
  );
}

export default App;
