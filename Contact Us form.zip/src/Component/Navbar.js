 import React from 'react'
 import Nav from './Nav.css'

const Navbar = () => {
    return (
        <div>
           <nav>
            <div>
                <img src="/images/Frame.png" alt='Frame-Logo'></img>
            </div>
            <ul>
                <li>Menu</li>
                <li>About</li>
                <li>Contact</li>
            </ul>
           </nav> 
        </div>
    )
}

export default Navbar
