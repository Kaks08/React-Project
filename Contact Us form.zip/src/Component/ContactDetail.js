import React, { useState } from 'react'
import { MdMessage } from "react-icons/md";
import ContactD from './ContactD.css'
import { IoMdCall } from "react-icons/io";

const ContactDetail = () => {

    const[name,setName] = useState("");
    const[email,setEmail]  =useState("");
    const [text,setText] = useState("");

const onviaclick = () =>
{
    console.log('I am from call');
}
const onsubmit = (event) =>{
    event.preventDefault();
     setName(event.target[0].value); 
     setEmail(event.target[1].value);
     setText(event.target[2].value); 
    console.log(event);  
}

    return (
    <section className='container'> 
        <div className='main'>
            <div className='Button'>
                <button><MdMessage />VIA SUPPORT CHAT</button>
                <button onClick={onviaclick}><IoMdCall/>VIA CALL</button>
            </div>
            <div className='email-btn'>
                <button><MdMessage />VIA EMAIL FORM</button>
            </div>

            <form className='form' onSubmit={onsubmit}>
                <div className='form-control'>
                    <label htmlFor='name'>Name</label>
                    <input type='text' name='name'></input>
                </div>
                 <div className='form-control'>
                    <label htmlFor='email'>E-mail</label>
                    <input type='email' name='email'></input>
                </div>
                 <div className='form-control'>
                    <label htmlFor='text'>Text</label>
                    <textarea type='text' width='100%' name='text'rows={5} ></textarea>
                </div>
                <div className='bottom-btn'>
                    <button><MdMessage />SUBMIT</button>
                    <div>{name +" "+email+" "+text}</div>        
                </div>
            </form>  
        </div>
        <div>
            <img src='/images/Service.png' alt='service'></img>
        </div>
     </section>
    )
}

export default ContactDetail
