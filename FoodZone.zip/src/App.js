  import logo from './logo.svg';
  import './App.css';
  import styled from 'styled-components';
  import { useEffect, useState } from 'react';
  import FoodCards from './Component/FoodContainer/FoodCards';


  const BASE_URL = "http://localhost:9000/";

  function App() {

    const [data,setData] = useState(null);
    const [loading,setLoading] =useState(false);
    const [error,setError] = useState(null);
    const [filterData, setFilterData] = useState(null);
    const[selectedbtn,setSelectedbtn] = useState(null);

const filterbtns = [
  {
    name:"All",
    type:"all",
  },
  {
    name:"Breakfast",
    type:"breakfast",
  },
  {
    name:"Lunch",
    type:"lunch",
  },
  {
    name:"Dinner",
    type:"dinner",
  }
]

    const filterButton = (type)=>{
      if(type === "all")
      {
        setFilterData(data);
        setSelectedbtn("all");
        return;
      }

      const filter = data?.filter((food) => food.type.toLowerCase().includes(type.toLowerCase()))

      setFilterData(filter);
      setSelectedbtn(type);
    }

    const searchfoodname = (e) => {
      const searchfood = e.target.value;
      console.log(searchfood);

      if(searchfood === null)
      {
        setFilterData(null);
      }

      const filter = data?.filter((food)=> food.name.toLowerCase().includes(searchfood));

      setFilterData(filter);
    }

    useEffect(() =>
    {
      const FoodData = async() =>{
        setLoading(true)
        try {
          const response = await fetch(BASE_URL); 
          const json =await response.json();
          console.log(json);
          setData(json);
          setFilterData(json)
          setLoading(false)
        } catch (error) {
          setError("Unable to Load Page.......")
        }
      
      }

      FoodData();

    },  [])

    if(loading) return <div>Loading.......</div>
    if(error) return <div>{error}</div>
  // FoodData();


    return (
      <div className="App">
        <MainContainer>
          <TopContainer>
              <div className="log o">
                <img src="/logo.png" alt="Logo"></img>
              </div>
              <input onChange={searchfoodname} type='search' placeholder='Search Food...'></input>
          </TopContainer>
          <ButtonContainer>
            {filterbtns?.map((btn) =>
            <button isSelected = {selectedbtn === btn.type} key={btn.name} onClick={()=>{filterButton(btn.type)}}>{btn.name}</button>
            )}
          </ButtonContainer>

          <FoodCards data1 = {filterData}/> 
        </MainContainer>
      
        
      

      </div>
    );
  }

  export default App;


  const MainContainer = styled.div`
  `

  const TopContainer  = styled.div`
  display: flex;
  justify-content: space-between;
  margin: 0 auto;
  align-items:center;
  max-width: 1200px;  
  height: 140px;
  .logo
  {
    width: 185px;
    height: 39px;
  }
  input{
    width: 285px;
    height: 40px;
    border-radius: 5px;
    border-color: #FF0909;
    background-color: transparent;
    color: white;
  }

  @media(0 < width < 800px){
   flex-direction: column;
   height: 120px;
  }
  `

  const ButtonContainer = styled.div`
  max-width: 326px;
  min-height: 60px;
  margin: 0 auto;
  display: flex;
  gap: 14px;

  button{
    background-color:${({isSelected}) => (isSelected ? "green": "red")};
    width: 74px;
    height: 31px;
    color: white;
    border: none;
    padding: 6px 12px;
    border-radius: 5px;
    cursor: pointer;
    &:hover{
      background-color: #FF4365;
    }
  }
  `

