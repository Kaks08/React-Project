import React from 'react'

const Front = () => {
    return (
        <div>
            <nav>
                <div>
                <img src="/images/Frame.png" alt="Frame"></img>
                </div>
                <ul>
                    <li>Home</li>
                    <li>About</li>
                    <li>Contact</li>
                </ul>
                
            </nav>
        </div>
    )
}

export default Front
