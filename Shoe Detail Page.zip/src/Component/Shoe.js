

const Shoe = () => {

    return(
        <main>
            <div className="shoe-content">
                <h1 className="heading">
                YOUR FEET 
                DESERVE
                THE BEST
                </h1>
                <p className="paragraph">
                YOUR FEET DESERVE THE BEST AND WE’RE HERE TO
                 HELP YOU WITH OUR SHOES.YOUR FEET DESERVE 
                 THE BEST AND WE’RE HERE TO HELP YOU WITH OUR 
                 SHOES. 
                </p>

                <div className="btn"> 
                <button className="primary-btn">Shop Now</button>
                <button className="secondary-btn">Category</button>
                </div>

                <div className="shopping">
                    <p>Also Available On</p>
                    <div className="brand-icon">
                    <img src="/images/amazon.png" alt="amazon"></img>
                    <img src="/images/flipkart.png" alt="flipkart"/>
                    </div>
                </div>
            </div>
            <div className="shoe-img">
                <img src="/images/shoe_image.png" alt="shoe"></img>
            </div>


        </main>

    );
};

export default Shoe;