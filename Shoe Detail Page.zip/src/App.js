//import logo from './logo.svg';
import Navbar from './Component/Navbar';
import Shoe from './Component/Shoe';
  import './App.css';
import Front from './Component/Front';

function App() {
  return (
    <div className="App">
      <Navbar/>
      <Shoe/>
      {/* <Front/> */}
    </div>
  );
}

export default App;
